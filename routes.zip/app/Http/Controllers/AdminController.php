<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Testimonial;
use App\Models\User;
use App\Models\Wjob;
use App\Models\ApplyJob;
use App\Models\BookingOrder;
use App\Models\PaymentConfirm;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function redirect(){
        if (Auth::id()) {

            if (Auth::user()->user_type=='0') {
                return redirect()->route('home');
            }else{
             
             return redirect()->route('dashboard');
            }
        }else{
            return redirect()->back();
        }
    }

    public function showDashboard(){
        $orders = BookingOrder::where('admin_delete', '=', 0)
         ->where('payment_status', '=', 'Paid')
         ->where('time_up', '=', 0)
         ->get();
        $recent_order = BookingOrder::where('payment_status', '=', "Paid")->orderBy('id', "Desc")->offset(0)->limit(5)->get();
        $all_jobs = Wjob::all();
        $all_apply_job = ApplyJob::all();
        $all_user = User::all();
        $all_testimonials = Testimonial::all();
        return view('backend.dashboard', compact('all_jobs', 'all_apply_job', 'all_user', 'all_testimonials', 'recent_order','orders'));
    }
}
