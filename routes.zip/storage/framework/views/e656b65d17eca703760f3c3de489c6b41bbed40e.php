
<?php $__env->startSection('title'); ?>
<?php echo e($job_details->position); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Breadcrumb Section Begin -->
<div class="breadcrumb-section mt-7" style="padding-top: 120px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <h2><?php echo e($job_details->position); ?></h2>
                        <div class="bt-option">
                            <a href="<?php echo e(route('home')); ?>">Home</a>
                            <span><?php echo e($job_details->position); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->


 <!-- Job Detail Start -->
 <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s" style="margin-top: -80px;">
    <div class="container">
        <div class="row gy-5 gx-4">
            <div class="col-lg-8">
                <div class="d-flex align-items-center mb-5">
                    <img class="flex-shrink-0 img-fluid  rounded" src="https://cdn0.iconfinder.com/data/icons/media-and-advertisement-1/49/18-512.png" alt="" style="width: 80px; height: 80px;">
                    <div class="text-start ps-4 job-details">
                        <h3 class="mb-3"><?php echo e($job_details->position); ?></h3>
                        <span class="text-truncate me-3"><i class="fa fa-map-marker-alt  me-2"></i><?php echo e($job_details->location); ?></span>
                        <span class="text-truncate me-3"><i class="far fa-clock me-2"></i><?php echo e($job_details->jobType); ?></span>
                        <span class="text-truncate me-0"><i class="far fa-money-bill-alt  me-2"></i>#<?php echo e($job_details->salary); ?></span>
                    </div>
                </div>
               
                <div class="mb-5">
                    <h4 class="mb-3">Job description</h4>
                    <p style="padding-left:30px;"><?php echo html_entity_decode($job_details->description); ?></p>
                    <h4 class="mb-3">Responsibility</h4>
                    <p style="padding-left:30px;"><?php echo html_entity_decode($job_details->responsibility); ?></p>
                   
                    <h4 class="mb-3">Qualifications</h4>
                    <p style="margin-left:30px !important;"><?php echo html_entity_decode($job_details->qualification); ?></p>
                    
                </div>

                <div class="">
                   
                    <div class="review-add">
                        <h4 class="">Apply For The Job</h4>
                        <form action="<?php echo e(route('job.apply')); ?>" method="post" class="ra-form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <label>Full Name <sup style="color: red;">*</sup></label>
                                    <input name="fullname" type="text" placeholder="Full Name">
                                    <p style="color:red; font-weight:500;">
                                        <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </p>
                                </div>
                                <div class="col-lg-12">
                                    <label>Phone Number <sup style="color: red;">*</sup></label>
                                    <input name="phoneNumber" type="text" placeholder="Phone Number">
                                    <p style="color:red; font-weight:500;">
                                        <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </p>
                                </div>
                                <div class="col-lg-12">
                                    <label>Email <sup style="color: red;">*</sup></label>
                                    <input name="email" type="text" placeholder="Email">
                                    <p style="color:red; font-weight:500;">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </p>
                                </div>
                                <div class="col-lg-12">
                                    <label>Resume/Cv <sup style="color: red;">*</sup></label>
                                    <input type="file" name="resume" placeholder="Your Resume">
                                   
                                    <p style="color:red; font-weight:500;">
                                        <?php $__errorArgs = ['resume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </p>
                                </div>
                                
                                <div class="col-lg-12">
                                    <label>Cover Letter <sup>optional</sup></label>
                                    <textarea name="cover_letter" placeholder="Your Cover Letter"></textarea>
                                    <input type="hidden" name="jobTitle" value="<?php echo e($job_details->position); ?>" >
                                    <button type="submit">Submit Now</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="bg-light rounded p-5 mb-4 wow slideInUp" data-wow-delay="0.1s">
                    <h4 class="mb-4">Job Summary</h4>
                    <p><i class="fa fa-angle-right text-dark me-2" style="padding: 10px;"></i>Published On: <?php echo e(date('d-m-Y', strtotime($job_details->created_at))); ?> </p>
                    <p><i class="fa fa-angle-right text-dark me-2" style="padding: 10px;"></i>Vacancy: <?php echo e($job_details->vacancy); ?></p>
                    <p><i class="fa fa-angle-right text-dark me-2"style="padding: 10px;"></i>Job Nature: <?php echo e($job_details->jobType); ?></p>
                    <p><i class="fa fa-angle-right text-dark me-2"style="padding: 10px;"></i>Salary: #<?php echo e($job_details->salary); ?></p>
                    <p><i class="fa fa-angle-right text-dark me-2"style="padding: 10px;"></i>Location: <?php echo e($job_details->location); ?></p>
                    <p class="m-0"><i class="fa fa-angle-right text-dark me-2" style="padding: 10px;"></i>Deadline: <?php echo e(date('d-m-Y', strtotime($job_details->deadline))); ?></p>
                </div>
                <div class="bg-light rounded p-5 wow slideInUp" data-wow-delay="0.1s">
                    <h4 class="mb-4">Company Detail</h4>
                    <p class="m-0">Ipsum dolor ipsum accusam stet et et diam dolores, sed rebum sadipscing elitr vero dolores. Lorem dolore elitr justo et no gubergren sadipscing, ipsum et takimata aliquyam et rebum est ipsum lorem diam. Et lorem magna eirmod est et et sanctus et, kasd clita labore.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Job Detail End -->
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/job-details.blade.php ENDPATH**/ ?>