
<?php $__env->startSection('title'); ?>
<?php echo e('Jobs'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Breadcrumb Section Begin -->
<div class="breadcrumb-section mt-7" style="padding-top: 120px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <h2>All Jobs</h2>
                        <div class="bt-option">
                            <a href="<?php echo e(route('home')); ?>">Home</a>
                            <span>All Jobs</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->


    <!-- Jobs Start -->
<section class="container" style="margin-top: -70px;" >
   
 
<?php if(count($jobs_for_user) > 0): ?>
<?php $__currentLoopData = $jobs_for_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="job-item" style="padding: 20px; box-shadow: rgba(0, 0, 0, 0.16) 0px 3px 6px, rgba(0, 0, 0, 0.23) 0px 3px 6px; margin: 20px 0px;">
        <div class="row g-4">
            <div class="col-sm-12 col-md-8 d-flex align-items-center">
                <img class="flex-shrink-0 img-fluid  rounded" src="https://cdn0.iconfinder.com/data/icons/media-and-advertisement-1/49/18-512.png" alt=""
                    style="width: 80px; height: 80px;">
                <div class="text-start ps-4 job-posting">
                    <h5 class="mb-3 job-posting"><?php echo e($job->position); ?></h5>
                    <span class="text-truncate me-3"><i class="fas fa-map-marker-alt  me-2"></i><?php echo e($job->location); ?></span>
                    <span class="text-truncate me-3"><i class="fas fa-clock  me-2"></i><?php echo e($job->jobType); ?></span>
                    <span class="text-truncate me-0"><i class="fas fa-money-bill-alt me-2"></i><?php echo e($job->salary); ?></span>
                </div>
            </div>
            <div class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center">
                <div class="d-flex mb-3 job-apply">
    
                    <a class="" href="<?php echo e(route('job.details', $job->position_slug)); ?>">Apply Now</a>
                </div>
                <small class="text-truncate" ><i class="far fa-calendar-alt    me-2" style="padding: 2px;"></i>Deadline: <?php echo e(date('d-m-Y', strtotime($job->deadline))); ?></small>
            </div>
        </div>
    </div>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-lg-12">
                    <div class="room-pagination">
                       
                        <?php echo e($jobs_for_user->links('paginate')); ?>

                       
                    </div>
                </div>
<?php else: ?>
<?php endif; ?>
</section>
    
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
    <!-- Jobs End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/jobs.blade.php ENDPATH**/ ?>