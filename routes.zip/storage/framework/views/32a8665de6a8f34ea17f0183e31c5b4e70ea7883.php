
<?php $__env->startSection('title'); ?>
<?php echo e('Rooms'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- Breadcrumb Section Begin -->
 <div class="breadcrumb-section mt-7" style="padding-top: 120px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <h2>All Apartments</h2>
                        <div class="bt-option">
                            <a href="<?php echo e(route('home')); ?>">Home</a>
                            <span>Apartments</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->

<section class="rooms-section spad">
        <div class="container">
            <div class="row">
                <?php if(!empty($rooms)): ?>
                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="room-item">
                        <img src="<?php echo e($room->poster_img); ?>" alt="">
                        <div class="ri-text">
                            <h4><?php echo e($room->label->room_label); ?></h4>
                            <h3>#<?php echo e($room->price); ?><span>/Pernight</span></h3>
                            <table>
                                <tbody>
                                <tr>
                                        <td class="r-o">Room Status:</td>
                                       <?php if($room->status =="Available"): ?>
                                       <td><span class="btn btn-success btn-sm"><?php echo Str::limit(html_entity_decode($room->status),20,"..."); ?></span></td>
                                       <?php else: ?>
                                       <td><span class="btn btn-warning btn-sm"><?php echo Str::limit(html_entity_decode($room->status),20,"..."); ?></span></td>
                                       <?php endif; ?>
                                        </tr>
                                <tr>
                                    <td class="r-o">Capacity:</td>
                                    <td><?php echo Str::limit(html_entity_decode($room->capacity),20,"..."); ?></td>
                                </tr>
                                
                                <tr>
                                    <td class="r-o">Services:</td>
                                    <td><?php echo Str::limit(html_entity_decode($room->service),20,"..."); ?></td>
                                </tr>
                                </tbody>
                            </table>
                                <?php if($room->status =="Available"): ?>
                                <a href="<?php echo e(route('room.detail', $room->label->room_label_slug )); ?>" class="primary-btn">More Details</a>
                                <?php else: ?>
                                <a class="primary-btn " data-toggle="modal" data-target="#exampleModal1" >Unavailable for reservation</a>
                                <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                <div class="col-lg-12">
                    <div class="room-pagination">
                       
                        <?php echo e($rooms->links('paginate')); ?>

                       
                    </div>
                </div>
            <?php else: ?>
            <div class="text-center text-danger" style="padding:40px 0px"><h3>No Available Room</h3></div>
            <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- Rooms Section End -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/rooms.blade.php ENDPATH**/ ?>