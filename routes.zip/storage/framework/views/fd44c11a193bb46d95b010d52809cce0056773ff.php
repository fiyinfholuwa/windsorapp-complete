


 <?php $__env->startSection('content'); ?>
 
 <main id="main" class="main">



<section class="section dashboard">
  <div class="row">

  <div class="col-lg-12">

<div class="card">
  <div class="card-body">
    <h5 class="card-title">Edit Testimonial</h5>
   
    <!-- Custom Styled Validation -->
    <form action="<?php echo e(route('testimonial.update', $testimonial_data->id)); ?>" method="post" class="row g-3 needs-validation" enctype="multipart/form-data" novalidate>
      <?php echo csrf_field(); ?>
      <div class="col-md-6">
        <label for="validationCustom01" class="form-label">Full Name</label>
        <input type="text" class="form-control" name="fullname" value="<?php echo e($testimonial_data->fullname); ?>" id="validationCustom01"  required>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        <div class="invalid-feedback">
          fullname required
        </div>
      </div>
      <div class="col-md-6">
        <label for="validationCustom02" class="form-label">Occupation</label>
        <input type="text" class="form-control" value="<?php echo e($testimonial_data->occupation); ?>" name="occupation" id="validationCustom02"  required>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        <div class="invalid-feedback">
          occupation required
        </div>
      </div>
      <div class="col-md-12">
        <label for="validationCustomUsername" class="form-label">Testimonial Image</label>
       
        <input type="file" class="form-control" name="test_image"  id="file-upload" accept="image/*" onchange="previewImage(event);" >
       
        <img height="50px" src="<?php echo e(asset($testimonial_data->test_image)); ?>" width="50px" id="preview-selected-image" />
          <div class="invalid-feedback">
            testimony image required
          </div>
      
      </div>
     
      <div class="col-md-12">
        <label for="validationCustomUsername" class="form-label">Testimony</label>
       
        <textarea class="form-control" name="content" placeholder="Write Testimony here" required><?php echo e($testimonial_data->content); ?></textarea>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        
          <div class="invalid-feedback">
            testimony required
          </div>
      
      </div>
     
     
      <div class="col-12">
        <button class="btn btn-primary" type="submit">Update Testimonial</button>
      </div>
    </form><!-- End Custom Styled Validation -->

  </div>
</div>

    </div>
</div><!-- End Left side columns -->

  

  </div>
</section>

</main><!-- End #main -->

 <script>
   const previewImage = (event) => {
    /**
     * Get the selected files.
     */
    const imageFiles = event.target.files;
    /**
     * Count the number of files selected.
     */
    const imageFilesLength = imageFiles.length;
    /**
     * If at least one image is selected, then proceed to display the preview.
     */
    if (imageFilesLength > 0) {
        /**
         * Get the image path.
         */
        const imageSrc = URL.createObjectURL(imageFiles[0]);
        /**
         * Select the image preview element.
         */
        const imagePreviewElement = document.querySelector("#preview-selected-image");
        /**
         * Assign the path to the image preview element.
         */
        imagePreviewElement.src = imageSrc;
        /**
         * Show the element by changing the display value to "block".
         */
        imagePreviewElement.style.display = "block";
    }
};
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/edit-testimonial.blade.php ENDPATH**/ ?>