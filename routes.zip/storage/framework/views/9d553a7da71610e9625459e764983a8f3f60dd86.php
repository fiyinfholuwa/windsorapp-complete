


 <?php $__env->startSection('content'); ?>
 
 <main id="main" class="main">



<section class="section dashboard">
  <div class="row">

        <!-- Recent Sales -->
        <div class="col-12">
          <div class="card recent-sales overflow-auto">

           

            <div class="card-body">
              <h5 class="card-title">All Jobs <span></span></h5>

              <table class="table table-borderless datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Position</th>
                    <th scope="col">Location</th>
                    <th scope="col">No of Vacancy</th>
                    <th scope="col">Job Type</th>
                    <th scope="col">Salary</th>
                    <th scope="col">Deadline</th>
                    <th scope="col">Description</th>
                    <th scope="col">Responsibility</th>
                    <th scope="col">Qualification</th>

                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody>
                 
                <?php $num = 1; ?>
              <?php if(count($jobs) > 0): ?>

              <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             
                      <tr>
                          <td><?php echo e($num++); ?></td>
                          <td><?php echo e($job->position); ?></td>
                          <td><?php echo e($job->location); ?></td>
                          <td><?php echo e($job->vacancy); ?></td>
                          <td><?php echo e($job->jobType); ?></td>
                          <td><?php echo e($job->salary); ?></td>
                         
                          <td><?php echo e(date('d-m-Y', strtotime($job->deadline))); ?></td>
                          <td> <?php echo Str::limit(html_entity_decode($job->description),20,"..."); ?></td>
                          <td> <?php echo Str::limit(html_entity_decode($job->responsibility),20,"..."); ?></td>
                          <td> <?php echo Str::limit(html_entity_decode($job->qualification),20,"..."); ?></td>
                         
                          <td>
                        
                          <a href="<?php echo e(route('job.edit', $job->id)); ?>" ><i style="color:blue;" class="bi bi-pencil-square"></i></a>
                          <a href="#" data-toggle="modal" data-target="#job_<?php echo e($job->id); ?>" ><i style="color:red;" class="bi bi-trash"></i></a>
                        </td>
                          <?php echo $__env->make('backend.modals.deleteJob', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </tr>
                       
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>
              <tr>
                <td colspan="5" class="text-center">No Data Found</td>
              </tr>
            <?php endif; ?>
                </tbody>
              </table>

            </div>

          </div>
        </div><!-- End Recent Sales -->

    

      </div>
    </div><!-- End Left side columns -->

  

  </div>
</section>

</main><!-- End #main -->

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/all-jobs.blade.php ENDPATH**/ ?>