


 <?php $__env->startSection('content'); ?>
 
 <main id="main" class="main">



<section class="section dashboard">
  <div class="row">

        <!-- Recent Sales -->
        <div class="col-12">
          <div class="card recent-sales overflow-auto">

           

            <div class="card-body">
              <h5 class="card-title">Active Bookings<span></span></h5>

              <table class="table table-borderless datatable">
              <thead>
                      <tr>
                        <th scope="col">#BookingId</th>
                        <th scope="col">CheckIn</th>
                        <th scope="col">CheckOut</th>
                        <th scope="col">Guest</th>
                       <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php if(count($orders)> 0): ?>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <tr>
                       <td><?php echo e($order->bookingId); ?></td>
                       <td><?php echo e($order->checkIn); ?></td>
                       <td><?php echo e($order->checkOut); ?></td>
                       <td><?php echo e($order->guest); ?></td>
                       <td>
                        
                        <a href="<?php echo e(route('booking.edit', $order->id)); ?>" ><i style="color:blue;" class="bi bi-pencil-square"></i></a>
                        <a href="#" data-toggle="modal" data-target="#booking_<?php echo e($order->id); ?>" ><i style="color:red;" class="bi bi-trash"></i></a>
                      </td>
                        <?php echo $__env->make('backend.modals.deleteBooking', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php else: ?>
                     <p class="text-center">No recent Order</p>
                     <?php endif; ?>

                      
                    </tbody>
              </table>

            </div>

          </div>
        </div><!-- End Recent Sales -->

    

      </div>
    </div><!-- End Left side columns -->

  

  </div>
</section>

</main><!-- End #main -->

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/active-booking.blade.php ENDPATH**/ ?>