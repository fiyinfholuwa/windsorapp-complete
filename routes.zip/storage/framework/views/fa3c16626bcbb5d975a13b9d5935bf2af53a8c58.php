<?php if($paginator->lastPage() > 1): ?>
   
    <div class="col-lg-12">
        <div class="room-pagination">
            <a href="<?php echo e($paginator->url($paginator->currentPage()-1)); ?>">Previous</a>
            <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
           
                <a href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
           
            <?php endfor; ?>
           
            <a href="<?php echo e($paginator->url($paginator->currentPage()+1)); ?>">Next <i class="fa fa-long-arrow-right"></i></a>
        </div>
    </div>
<?php endif; ?>

                <?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/paginate.blade.php ENDPATH**/ ?>