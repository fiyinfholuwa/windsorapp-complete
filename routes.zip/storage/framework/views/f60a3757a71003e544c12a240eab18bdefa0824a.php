


 <?php $__env->startSection('content'); ?>
 
 <main id="main" class="main">



<section class="section dashboard">
  <div class="row">

        <!-- Recent Sales -->
        <div class="col-12">
          <div class="card recent-sales overflow-auto">

           

            <div class="card-body">
              <h5 class="card-title">All Rooms <span></span></h5>

              <table class="table table-borderless datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Room Label</th>
                    <th scope="col">Price</th>
                    <th scope="col">Capacity</th>
                    <th scope="col">Services</th>
                    <th scope="col">Poster Image</th>
                    <th scope="col">Image 2</th>
                    <th scope="col">Image 3</th>
                    <th scope="col">Image 4</th>
                    <th scope="col">Status</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody>
                 
                 
                <?php if(count($rooms) > 0): ?>
                <?php $num = 1; ?>
              <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                  <td><?php echo e($num++); ?></td>
                  <td><?php echo e($room->label->room_label); ?></td>
                  <td><?php echo e($room->price); ?></td>
                  <td> <?php echo Str::limit(html_entity_decode($room->capacity),20,"..."); ?></td>
                  <td> <?php echo Str::limit(html_entity_decode($room->service),20,"..."); ?></td>
                  <td><img src="<?php echo e(asset($room->poster_img)); ?>" height="40px" width="40px" /></td>
                  <td><img src="<?php echo e(asset($room->image_2)); ?>" height="40px" width="40px" /></td>
                  <td><img src="<?php echo e(asset($room->image_3)); ?>" height="40px" width="40px" /></td>
                  <td><img src="<?php echo e(asset($room->image_4)); ?>" height="40px" width="40px" /></td>
                  <td><?php if($room->status =="Available"): ?>
                  <span  class="btn btn-success btn-sm" style="font-size: 8px;">Available</span>
                  <?php else: ?>
                  <span  class="btn btn-warning btn-sm" style="font-size: 8px;">Unavailable</span>
                  <?php endif; ?>
                  </td>
                  
                  <td>
                  <a href="<?php echo e(route('room.edit', $room->id)); ?>" ><i style="color:blue;" class="bi bi-pencil-square"></i></a>    
                  <a href="#" data-toggle="modal" data-target="#deleteRoom_<?php echo e($room->id); ?>" ><i style="color:red;" class="bi bi-trash"></i></a>
                  <?php echo $__env->make('backend.modals.deleteRoom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </td>
                
                </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>
              <tr>
                <td colspan="5" class="text-center">No Data Found</td>
              </tr>
            <?php endif; ?>
                </tbody>
              </table>

            </div>

          </div>
        </div><!-- End Recent Sales -->

    

      </div>
    </div><!-- End Left side columns -->

  

  </div>
</section>

</main><!-- End #main -->

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/all-rooms.blade.php ENDPATH**/ ?>