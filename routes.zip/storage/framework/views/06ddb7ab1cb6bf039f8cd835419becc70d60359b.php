
    <!-- Modal -->
<div class="modal fade" id="confirm_<?php echo e($confirm->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
  <form action="<?php echo e(route('confirm.delete', $confirm->id)); ?>" method="post">
   <?php echo csrf_field(); ?>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-danger" id="exampleModalLabel"> Payment Confirmation</h5>
        
      </div>
      <?php if($confirm->verify_status == "accepted" || $confirm->verify_status == "rejected"): ?>
      
        <div class="modal-body">
        Are You Sure You want to delete this Payment Confirmation
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">Delete</button>
      </div>
    </div>
       
        <?php else: ?>
        <div class="modal-body">
       You cannot delete this Payment confirmation because you have not verified it
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>  
      </div>
    </div>
        <?php endif; ?>
     
    </form>
  </div>
</div>

<?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/modals/deleteConfirm.blade.php ENDPATH**/ ?>