
<?php $__env->startSection('title'); ?>
<?php echo e('Rooms'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- Breadcrumb Section Begin -->
 <div class="breadcrumb-section mt-7" style="padding-top: 120px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <h2>My Booking</h2>
                        <div class="bt-option">
                            <a href="<?php echo e(route('home')); ?>">Home</a>
                            <span>My Booking</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->

    <section class="contact-section spad " style="margin-top: -130px;">
        <div class="container">
            <div class="d-flex justify-content-center row">
                <div class="col-md-12">
                    <div class="rounded">
                        <div class="table-responsive table-borderless">
                            <table class="table">
                                <thead>
                                    <tr>
                                        
                                        <th class="text-center">BookingID #</th>
                                        <th class="text-center">Reference</th>
                                        <th class="text-center">Check In</th>
                                        <th class="text-center">Check Out</th>
                                        <th class="text-center">Guest</th>
                                        <th class="text-center">Amount</th>
                                        <th class="text-center"> Payment Status</th>
                                        <th class="text-center">Actions</th>
                                       
                                     
                                    </tr>
                                </thead>
                                <tbody class="table-body">
                                <?php if(count($bookings) > 0): ?>
                                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <td>#<?php echo e($booking->bookingId); ?></td>
                                        <td><?php echo e($booking->reference); ?></td>
                                        <td><?php echo e($booking->checkIn); ?></td>
                                        <td><?php echo e($booking->checkOut); ?></td>
                                        <td>
                                            <?php if($booking->guest === "1"): ?>
                                            <?php echo e($booking->guest); ?> person
                                            <?php else: ?>
                                            <?php echo e($booking->guest); ?> persons
                                            <?php endif; ?>
                                        </td>
                                       
                                        <td>#<?php echo e($booking->price); ?></td>
                                        <td>
                                            <?php if($booking->payment_status === "Paid"): ?>
                                            <span class="badge badge-success">Paid</span>
                                            <?php elseif($booking->payment_status === "Pending"): ?>
                                            <span class="badge badge-warning">Payment Pending</span>
                                            <?php else: ?>
                                            <span class="badge badge-danger"><?php echo e($booking->payment_status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                       
                                        <td> 
                                             <?php if($booking->payment_status === "Paid"): ?>
                                             <a href="<?php echo e(route('invoice.generate' , $booking->id)); ?>" class="badge badge-danger">Download Invoice</a>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('invoice.generate' , $booking->id)); ?>" class="badge badge-danger">Download Invoice</a>  <a href="<?php echo e(route('make.payment' , $booking->id)); ?>" class="badge badge-warning">Make Payment</a></td>
                                            <?php endif; ?>    
                                    
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                </tbody>
                               
                            </table>
                            <div class="col-lg-12">
                                        <div class="room-pagination">
                                        
                                            <?php echo e($bookings->links('paginate')); ?>

                                        
                                        </div>
                                    </div>
                                <?php else: ?>
                                <table class="table">
                                <thead>
                                    <tr>
                                   
                                        <th class="text-center"><span>No Booking Yet</span></th>
                                       
                                     
                                    </tr>
                                </thead>
                                <tbody class="table-body">
                               
                               
                            </table>
                                <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Rooms Section End -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/mybooking.blade.php ENDPATH**/ ?>