<nav>
        <ul class="menu">
            <li class="logo"><a href="#"><img src="<?php echo e(asset('img/winsorlogo.png')); ?>" alt="companylogo" /></a></li>
            <li class="item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="item"><a href="<?php echo e(route('rooms')); ?>">Apartments</a></li>
            <li class="item"><a href="<?php echo e(route('about')); ?>">About Us</a></li>
            <li class="item"><a href="<?php echo e(route('jobs')); ?>">Jobs</a></li>
            <li class="item"><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
            <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::check() && Auth::user()->user_type == "1"): ?>
            <li class="item button"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
            <li class="item button"><a href="<?php echo e(route('booking.user')); ?>">My Bookings</a></li>
            <?php else: ?>
            <li class="item button"><a href="<?php echo e(route('booking.user')); ?>">My Bookings</a></li>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
            <li class="item"><button  type="submit" class="border-0" style="background:transparent; color: #C70039;">
             Logout
              </button></li>
          </form>
           
            <?php else: ?>
            <li class="item button"><a href="<?php echo e(route('login')); ?>">Login</a></li>
            <li class="item button secondary"><a href="<?php echo e(route('register')); ?>">Sign Up</a></li>
            <?php endif; ?>
           
            <li class="toggle"><span class="bars"></span></li>
        </ul>
    </nav><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>