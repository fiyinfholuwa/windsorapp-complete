


 <?php $__env->startSection('content'); ?>
 
 <main id="main" class="main">



<section class="section dashboard">
  <div class="row">

        <!-- Recent Sales -->
        <div class="col-12">
          <div class="card recent-sales overflow-auto">

           

            <div class="card-body">
              <h5 class="card-title">All Testimonials <span></span></h5>

              <table class="table table-borderless datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Full Name</th>
                    <th scope="col">Occupation</th>
                    <th scope="col">Image</th>
                    <th scope="col">Content</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody>
              
              <?php if(count($testimonials) > 0): ?>
              <?php $num = 1; ?>
              <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <tr>
                          <td><?php echo e($num++); ?></td>
                          <td><?php echo e($testimonial->fullname); ?></td>
                          <td><?php echo e($testimonial->occupation); ?></td>
                          <td><img src="<?php echo e(asset($testimonial->test_image)); ?>" height="40px" width="40px" /></td>
                          <td><?php echo e($testimonial->content); ?></td>
                          <td>
                        
                          <a href="<?php echo e(route('testimonial.edit', $testimonial->id)); ?>" ><i style="color:blue;" class="bi bi-pencil-square"></i></a>
                          <a href="#" data-toggle="modal" data-target="#test_<?php echo e($testimonial->id); ?>" ><i style="color:red;" class="bi bi-trash"></i></a>
                        </td>
                        <?php echo $__env->make('backend.modals.deleteTestimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <?php else: ?>
              <tr>
                <td colspan="5" class="text-center">No Data Found</td>
              </tr>
              <?php endif; ?>
                </tbody>
              </table>

            </div>

          </div>
        </div><!-- End Recent Sales -->

    

      </div>
    </div><!-- End Left side columns -->

  

  </div>
</section>

</main><!-- End #main -->

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/all-testimonials.blade.php ENDPATH**/ ?>