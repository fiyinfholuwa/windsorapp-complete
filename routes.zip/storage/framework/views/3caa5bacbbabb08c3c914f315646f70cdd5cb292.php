
<?php $__env->startSection('title'); ?>
<?php echo e($label_name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!-- Breadcrumb Section Begin -->
 <div class="breadcrumb-section" style="padding-top: 100px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <h2><?php echo e($label_name); ?></h2>
                        <div class="bt-option">
                            <a href="<?php echo e(route('home')); ?>">Home</a>
                            <span><?php echo e($label_name); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->

    <section class="room-details-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="room-details-item">
                        <!-- <img src="img/room/room-details.jpg" alt=""> -->
                        <div class = "card">
                            <!-- card left -->
                            <div class = "product-imgs">
                              <div class = "img-display">
                                <div class = "img-showcase">
                                  <img src = "<?php echo e($get_room_detail->poster_img); ?>" alt = "shoe image">
                                  <img src = "<?php echo e($get_room_detail->image_2); ?>" alt = "show image">
                                  <img src = "<?php echo e($get_room_detail->image_3); ?>" alt = "shoe image">
                                  <img src = "<?php echo e($get_room_detail->image_4); ?>" alt = "show image">
                                </div>
                              </div>
                              <div class = "img-select">
                                <div class = "img-item">
                                  <a href = "#" data-id = "1">
                                    <img src = "<?php echo e($get_room_detail->poster_img); ?>" alt = "show image">
                                  </a>
                                </div>
                                <div class = "img-item">
                                  <a href = "#" data-id = "2">
                                    <img src = "<?php echo e($get_room_detail->image_2); ?>" alt = "show image">
                                  </a>
                                </div>
                                <div class = "img-item">
                                  <a href = "#" data-id = "3">
                                    <img src = "<?php echo e($get_room_detail->image_3); ?>" alt = "shoe image">
                                  </a>
                                </div>
                                <div class = "img-item">
                                  <a href = "#" data-id = "4">
                                    <img src = "<?php echo e($get_room_detail->image_4); ?>" alt = "shoe image">
                                  </a>
                                </div>
                              </div>
                            </div>
                        </div>
                        <div class="rd-text">
                            <div class="rd-title">
                                <h3><?php echo e($label_name); ?></h3>
                                <div class="rdt-right">
                                    <!-- <div class="rating">
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star"></i>
                                        <i class="icon_star-half_alt"></i>
                                    </div> -->
                                    <a href="#booking">Booking Now</a>
                                </div>
                            </div>
                            <h2><?php echo e($get_room_detail->price); ?><span>/Pernight</span></h2>
                            <table>
                                <tbody>
                                   
                                    <tr>
                                        <td class="r-o">Capacity:</td>
                                        <td><?php echo e($get_room_detail->capacity); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td class="r-o">Services:</td>
                                        <td><?php echo e($get_room_detail->service); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            
                        </div>
                    </div>
                    <div class="rd-reviews">
                        <?php if(count($reviews)> 0): ?>
                        <h4>Reviews (<?php echo e(count($reviews)); ?>)</h4>
                        <?php else: ?>
                        <h4>Reviews (0)</h4>
                        <?php endif; ?>
                       <?php if(count($reviews)> 0): ?>
                       <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="review-item">
                            <div class="ri-pic">
                                <img src="https://cdn-icons-png.flaticon.com/512/147/147142.png" alt="">
                            </div>
                            <div class="ri-text">
                                <span><?php echo e(\Carbon\Carbon::parse($review->created_at)->isoFormat('MMM  Do, YYYY')); ?></span>
                                <!-- <div class="rating">
                                    <i class="icon_star"></i>
                                    <i class="icon_star"></i>
                                    <i class="icon_star"></i>
                                    <i class="icon_star"></i>
                                    <i class="icon_star-half_alt"></i>
                                </div> -->
                                <h5><?php echo e($review->reviewer_name); ?></h5>
                                <p><?php echo e($review->review_content); ?></p>
                            </div>
                        </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php else: ?>
                       <div style="text-align:center; color:red !important; padding:30px 0px"><h5 class="text-danger">No Review yet</h5></div>
                       <?php endif; ?>

                    </div>
                    <div class="review-add">
                       
                    
                        <?php if(Auth::check()): ?>
                        <h4>Add Review</h4>
                        <form action="<?php echo e(route('store.review')); ?>" method="post" class="ra-form">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                               
                                <div class="col-lg-12">
                                    <!-- <div>
                                        <h5>You Rating:</h5>
                                        <div class="rating">
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star"></i>
                                            <i class="icon_star-half_alt"></i>
                                        </div>
                                    </div> -->
                                    <input type="hidden" name="room_id" value="<?php echo e($get_room_detail->id); ?>" />
                                    <input type="hidden" name="reviewer_name" value="<?php echo e(Auth::user()->name); ?>" />
                                    <textarea name="review_content" placeholder="Your Review"></textarea>
                                    <p style="text-align:center; color:red;">
                                        <?php $__errorArgs = ['review_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </p>
                                    <button type="submit">Add Review</button>
                                </div>
                            </div>
                        </form>
                        <?php else: ?>
                       <div class="text-center"> <a href="<?php echo e(route('login')); ?>" class="btn btn-danger">You need to login before commenting your review</a></div>
                        <?php endif; ?>
                        
                    </div>
                </div>
                <div class="col-lg-4" id="booking">
                    <div class="room-booking">
                        <h3>Your Reservation</h3>
                        <form action="<?php echo e(route('pay')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="check-date">
                                <label for="date-in">Check In:</label>
                                <input type="text" class="date-input" name="checkIn" id="date-in">
                                <i class="icon_calendar"></i>
                                <p style="color:red">
                                    <?php $__errorArgs = ['checkIn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </p>
                            </div>
                            <div class="check-date">
                                <label for="date-out">Check Out:</label>
                                <input type="text" class="date-input" name="checkOut" id="date-out">
                                <i class="icon_calendar"></i>
                                <p style="color:red">
                                    <?php $__errorArgs = ['checkOut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </p>
                            </div>
                            <div class="select-option">
                                <label for="guest">Guests:</label>
                                <select name="guest" id="guest">
                                <option value="">Select Number of Guest</option>
                                    <option value="1">1 Person</option>
                                    <option value="2">2 Persons</option>
                                    <option value="3">3 Persons</option>
                                    <option value="4">4 Persons</option>
                                    <option value="5">5 Persons</option>
                                    <option value="6">6 Persons</option>
                                </select>
                                <p style="color:red">
                                    <?php $__errorArgs = ['guest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </p>
                            </div>
                            <!-- <div class="select-option">
                                <label for="room">Room:</label>
                                <select id="room">
                                    <option value="">1 Room</option>
                                </select>
                            </div> -->
                           <?php if(Auth::check()): ?>
                           <input type="hidden" name="apartment_id" value="<?php echo e($get_room_detail->id); ?>" />
                           <input type ="hidden" value="<?php echo e(Auth::user()->email); ?>" name="user_email" />
                           <input type ="hidden" value="<?php echo e($get_room_detail->price); ?>" name="price" />
                           <button type="submit" name="online_pay">CheckOut / Pay Online</button>
                           <button class="btn2" type="submit" ">Make Reservation / Offline Payment</button>
                           
                           <?php else: ?>
                           <a href="<?php echo e(route('login')); ?>" class="btn-2 btn btn-primary border-0">Login before making reservation.</a>
                           <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
 
    <!-- Rooms Section End -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/room_details.blade.php ENDPATH**/ ?>