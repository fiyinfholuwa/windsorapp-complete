
<?php $__env->startSection('title'); ?>
<?php echo e('Jobs'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Breadcrumb Section Begin -->
<div class="breadcrumb-section mt-7" style="padding-top: 120px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <h5>Make Payment / Payment Confirmation.</h5>
                        <div class="bt-option">
                            <a href="<?php echo e(route('home')); ?>">Home</a>
                            <span>Make Payment</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->


    <!-- Jobs Start -->
<section class="container" style="margin-top: -70px; margin-bottom:50px;" >
   
 <div style=" box-shadow: rgba(0, 0, 0, 0.25) 0px 0.0625em 0.0625em, rgba(0, 0, 0, 0.25) 0px 0.125em 0.5em, rgba(255, 255, 255, 0.1) 0px 0px 0px 1px inset; padding:30px">
 <h4 style="text-align:center; padding:15px 0px;">Amount to be Paid <span style="color:green; font-weight:500;">#<?php echo e($booking->price); ?></span></h4>
    <div class="row">
        <div class="col-lg-8">
            <h3>Account Details for Offline Payment.</h3>
            <div><p><strong><ul>
                <li><p>Acccount Name: Windsor Apartments and Allied Services Ltd.</p>
                    <p>Account Number: 221788015</p>
                    <p>Bank Name: FCMB</p>
                </li>
                <li>
                <p>Acccount Name: Windsor Apartments and Allied Services Ltd.</p>
                    <p>FCMB USD account : 9221788022</p>
                    
                </li>
            </ul></strong></p></div>
            <h3 class="mt-3 mb-2">Payment Confirmation</h3>
            <form action="<?php echo e(route('payment.confirm')); ?>" method="post" class="contact-form">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <input type="number" name="amount_sent" placeholder="Amount Sent in Naira #">
                                <?php $__errorArgs = ['amount_sent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red; font-weight: 400; text-align: center;"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-6">
                                <input type="text" name="bank_name" placeholder="Bank Name">
                                <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red; font-weight: 400; text-align: center;"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-12">
                                <input type="text" name="account_name" placeholder="Acount Name ">
                                <?php $__errorArgs = ['account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red; font-weight: 400; text-align: center;"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-12">
                            <input type="hidden" value='<?php echo e(Auth::user()->name); ?>' name="name" placeholder="Bank Name">
                            <input type="hidden" value='<?php echo e($booking->bookingId); ?>' name="bookingId" placeholder="Bank Name">
                                <button type="submit">Submit</button>
                            </div>
                        </div>
                    </form>
    </div>

        <div class="col-lg-4 mt-5">
        <h5 class="text-center">Make Online Payment</h5>
        <div>
            <form action="<?php echo e(route('make.payment.online')); ?>" method="post">
                <?php echo csrf_field(); ?>
            <input type="hidden" name="checkIn" value="<?php echo e($booking->checkIn); ?>" />
            <input type="hidden" name="checkOut" value="<?php echo e($booking->checkOut); ?>" />
            <input type="hidden" name="guest" value="<?php echo e($booking->guest); ?>" />
            <input type="hidden" name="user_email" value="<?php echo e($booking->user_email); ?>" />
            <input type="hidden" name="price" value="<?php echo e($booking->price); ?>" />
            <input type="hidden" name="bookingId" value="<?php echo e($booking->bookingId); ?>" />
           <div class="text-center mt-3"> <button type="submit" name="make_payments" class="btn btn-danger"/>Pay Online </button></div>
            </form>
        </div>
        <div>
    </div>
 </div>

    
</section>
    
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
    <!-- Jobs End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/make_payment.blade.php ENDPATH**/ ?>