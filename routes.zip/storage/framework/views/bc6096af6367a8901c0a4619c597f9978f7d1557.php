<?php $__env->startSection('title'); ?>
<?php echo e('Forgot Password'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="login-auth" style="background: url('https://cf.bstatic.com/xdata/images/hotel/max1024x768/321441959.jpg?k=ce000a7ae2797d40e4d056b72c03fddf7e2c0c5c867a28b6df9253399dab17ea&o=&hp=1') no-repeat ; background-size: cover;" style="min-height: 100vh;">
    <div class="login-form">    
    <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="avatar"><i class="fa fa-user"></i></div>
            <h4 class="modal-title">Recover Your Password  | <span style="font-size:14px !important; color:navy !important;"><a href="<?php echo e(route('home')); ?>">go to home</a></span></h4></h4>
            <div class="form-group">
                <p>Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.</p>
            </div>
            <div class="form-group">
                <input type="email" name="email" class="form-control" placeholder="Enter Your Email">
             
                <p style="color:red; font-weight:400;">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>
            </div>
           
            <input type="submit" class="btn btn-primary btn-block btn-lg" value="Create Password Reset Link">   
           
        </div>           
        </form>			
       
</section>
<!-- Footer Section Begin -->
<footer class="footer-section">
    
<div style="padding:10px 0px"><p class="text-center" style="padding: 20px 0px; font-size: 12px;">Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved Windsor Apartments</p></div>

</footer>
<!-- end login area  -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>