
    <!-- Modal -->
<div class="modal fade" id="test_<?php echo e($testimonial->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
  <form action="<?php echo e(route('delete.testimonial', $testimonial->id)); ?>" method="post">
   <?php echo csrf_field(); ?>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-danger" id="exampleModalLabel">Testimonial Delete</h5>
        
      </div>
      <div class="modal-body">
        Are You Sure You want to delete this Testimonial
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">Delete</button>
      </div>
    </div>
    </form>
  </div>
</div>
<?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/modals/deleteTestimonial.blade.php ENDPATH**/ ?>