


 <?php $__env->startSection('content'); ?>
 
 <main id="main" class="main">



<section class="section dashboard">
  <div class="row">

        <!-- Recent Sales -->
        <div class="col-lg-5">
        <div class="card">
  <div class="card-body">
    <h5 class="card-title">Update Room Label</h5>
   
    <!-- Custom Styled Validation -->
    <form action="<?php echo e(route('update.label', $room_label_d->id)); ?>" method="post" class="row g-3 needs-validation" enctype="multipart/form-data" novalidate>
      <?php echo csrf_field(); ?>
      <div class="col-md-12s">
        <label for="validationCustom01" class="form-label">Room Label</label>
        <input type="text" class="form-control" name="room_label" id="validationCustom01" placeholder="Room Label" value="<?php echo e($room_label_d->room_label); ?>"  required>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['room_label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        <div class="invalid-feedback">
          room label required
        </div>
      </div>
     
     
     
      <div class="col-12">
        <button class="btn btn-primary" type="submit">Update Room Label</button>
      </div>
    </form><!-- End Custom Styled Validation -->

  </div>
</div>
        </div>
        <div class="col-lg-7">
          <div class="card recent-sales overflow-auto">

           

            <div class="card-body">
              <h5 class="card-title">All Room Labels <span></span></h5>

              <table class="table table-borderless datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    
                    <th scope="col">Room Label</th>
                    <th scope="col">Status</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  
                <?php if(count($get_all_labels) > 0): ?>
                <?php $num = 1; ?>
              <?php $__currentLoopData = $get_all_labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                  <td><?php echo e($num++); ?></td>
                  <td><?php echo e($label->room_label); ?></td>
                
                  <td><?php if($label->label_status =="pending"): ?>
                  <span  class="btn btn-warning btn-sm" style="font-size: 8px;">Pending</span>
                  <?php else: ?>
                  <span  class="btn btn-success btn-sm" style="font-size: 8px;">Active</span>
                  <?php endif; ?>
                  </td>
                 <td>
                  <a href="<?php echo e(route('edit.label', $label->id)); ?>" ><i style="color:blue;" class="bi bi-pencil-square"></i></a>
                  <a href="#" data-toggle="modal" data-target="#label_<?php echo e($label->id); ?>" ><i style="color:red;" class="bi bi-trash"></i></a>
                  <?php echo $__env->make('backend.modals.deleteLabel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </td>
                
                </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>
              <tr>
                <td colspan="5" class="text-center">No Data Found</td>
              </tr>
            <?php endif; ?>
             
        
                </tbody>
              </table>

            </div>

          </div>
        </div><!-- End Recent Sales -->

    

      </div>
    </div><!-- End Left side columns -->

  

  </div>
</section>

</main><!-- End #main -->

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/manage-room-label-edit.blade.php ENDPATH**/ ?>