


 <?php $__env->startSection('content'); ?>
 
 <main id="main" class="main">



<section class="section dashboard">
  <div class="row">

  <div class="col-lg-12">

<div class="card">
  <div class="card-body">
    <h5 class="card-title">Add Room</h5>
   
    <!-- Custom Styled Validation -->
    <form action="<?php echo e(route('store.room')); ?>" method="post" class="row g-3 needs-validation" enctype="multipart/form-data" novalidate>
      <?php echo csrf_field(); ?>
      <div class="col-md-6">
        <label for="validationCustom01" class="form-label">Room Label</label>
        <div class="form-group">
        <select class="form-control" name="room_label_id" id="validationCustom02" placeholder="Select Room Label"  required>
        <option disabled selected >Select Room Label</option>
           <?php if(count($fetch_room_label) > 0): ?>
           <?php $__currentLoopData = $fetch_room_label; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <option value="<?php echo e($label->id); ?>"><?php echo e($label->room_label); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php else: ?>
           <option disabled>No room label available</option>
           <?php endif; ?>
        </select>
        <div class="invalid-feedback">
          room label required
        </div>
        </div>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['room_label_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        
      </div>
      <div class="col-md-6">
        <label for="validationCustom02" class="form-label">Price in Naira</label>
        <input type="number" class="form-control" name="price" id="validationCustom02" placeholder="Price in Naira"  required>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        <div class="invalid-feedback">
          price required
        </div>
      </div>
      
      <div class="col-md-12">
        <label for="validationCustomUsername" class="form-label">Capacity</label>
       
        <textarea class="form-control" name="capacity" placeholder="Room Capacity" required></textarea>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        
          <div class="invalid-feedback">
            capacity required
          </div>
      
      </div>
      <div class="col-md-12">
        <label for="validationCustomUsername" class="form-label">Room Services</label>
       
        <textarea class="form-control" name="services" placeholder="Services related to the room" required></textarea>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        
          <div class="invalid-feedback">
           room services required
          </div>
      
      </div>
      <div class="col-md-6">
        <label for="validationCustomUsername" class="form-label">Room Poster Image</label>
       
        <input type="file" class="form-control" name="poster_image"  id="file-upload" accept="image/*" onchange="previewImage(event);" required>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['poster_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        <img height="50px" width="50px" id="preview-selected-image" />
          <div class="invalid-feedback">
            room poster image
          </div>
      
      </div>

      <div class="col-md-6">
        <label for="validationCustomUsername" class="form-label">Room Image 2</label>
       
        <input type="file" class="form-control" name="image_2"  id="file-upload" accept="image/*" onchange="previewImage1(event);" required>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        <img height="50px" width="50px" id="preview-selected-image1" />
          <div class="invalid-feedback">
            room image 2
          </div>
      
      </div>

      <div class="col-md-6">
        <label for="validationCustomUsername" class="form-label">Room Image 3</label>
       
        <input type="file" class="form-control" name="image_3"  id="file-upload" accept="image/*" onchange="previewImage2(event);" required>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['image_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        <img height="50px" width="50px" id="preview-selected-image2" />
          <div class="invalid-feedback">
            room image 3
          </div>
      
      </div>

      <div class="col-md-6">
        <label for="validationCustomUsername" class="form-label">Room Image 4</label>
       
        <input type="file" class="form-control" name="image_4"  id="file-upload" accept="image/*" onchange="previewImage3(event);" required>
        <p style="color:red; font-weight:400;">
          <?php $__errorArgs = ['image_4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </p>
        <img height="50px" width="50px" id="preview-selected-image3" />
          <div class="invalid-feedback">
            room image 4
          </div>
      
      </div>
     
     
      <div class="col-12">
        <button class="btn btn-primary" type="submit">Add Room unit</button>
      </div>
    </form><!-- End Custom Styled Validation -->

  </div>
</div>

    </div>
</div><!-- End Left side columns -->

  

  </div>
</section>

</main><!-- End #main -->

 <script>
   const previewImage = (event) => {
    const imageFiles = event.target.files;
    const imageFilesLength = imageFiles.length;
    if (imageFilesLength > 0) {
        const imageSrc = URL.createObjectURL(imageFiles[0]);
        const imagePreviewElement = document.querySelector("#preview-selected-image");
        imagePreviewElement.src = imageSrc;
         imagePreviewElement.style.display = "block";
        }
    }

    const previewImage1 = (event) => {
    const imageFiles = event.target.files;
    const imageFilesLength = imageFiles.length;
    if (imageFilesLength > 0) {
        const imageSrc = URL.createObjectURL(imageFiles[0]);
        const imagePreviewElement = document.querySelector("#preview-selected-image1");
        imagePreviewElement.src = imageSrc;
         imagePreviewElement.style.display = "block";
        }
    }

    const previewImage2 = (event) => {
    const imageFiles = event.target.files;
    const imageFilesLength = imageFiles.length;
    if (imageFilesLength > 0) {
        const imageSrc = URL.createObjectURL(imageFiles[0]);
        const imagePreviewElement = document.querySelector("#preview-selected-image2");
        imagePreviewElement.src = imageSrc;
         imagePreviewElement.style.display = "block";
        }
    }

    const previewImage3 = (event) => {
    const imageFiles = event.target.files;
    const imageFilesLength = imageFiles.length;
    if (imageFilesLength > 0) {
        const imageSrc = URL.createObjectURL(imageFiles[0]);
        const imagePreviewElement = document.querySelector("#preview-selected-image3");
        imagePreviewElement.src = imageSrc;
         imagePreviewElement.style.display = "block";
        }
    }

    
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/create-room.blade.php ENDPATH**/ ?>