
    <!-- Modal -->
<div class="modal fade" id="label_<?php echo e($label->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
  <form action="<?php echo e(route('delete.label', $label->id)); ?>" method="post">
   <?php echo csrf_field(); ?>
    <div class="modal-content">
     <?php if($label->label_status == "pending"): ?>
     <div class="modal-header">
        <h5 class="modal-title text-danger" id="exampleModalLabel">Room Label Delete</h5>
        
      </div>
      <div class="modal-body">
        Are You Sure You want to delete this Room Label
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">Delete</button>
      </div>
     <?php else: ?>
     <div class="modal-header">
        <h5 class="modal-title text-danger" id="exampleModalLabel">Unable to delete This</h5>
        
      </div>
      <div class="modal-body">
       This room label has been attached to a room, except the room is deleted, you cant perform further actions, thank you. 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
       
      </div>
     <?php endif; ?>
    </div>
    </form>
  </div>
</div>
<?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/modals/deleteLabel.blade.php ENDPATH**/ ?>