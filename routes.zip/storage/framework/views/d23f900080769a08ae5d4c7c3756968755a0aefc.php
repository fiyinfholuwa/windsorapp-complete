


 <?php $__env->startSection('content'); ?>
 
 <main id="main" class="main">



<section class="section dashboard">
  <div class="row">

        <!-- Recent Sales -->
        <div class="col-12">
          <div class="card recent-sales overflow-auto">

           

            <div class="card-body">
              <h5 class="card-title">All Payment Confirmations.<span></span></h5>

              <table class="table table-borderless datatable">
              <thead>
                      <tr>
                        <th scope="col">#BookingId</th>
                        <th scope="col">Account Name</th>
                        <th scope="col">Bank Name</th>
                        <th scope="col">Amount Sent</th>
                        <th>Full Name</th>
                        <th>Confirmation Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php if(count($confirms)> 0): ?>
                    <?php $__currentLoopData = $confirms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $confirm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                       <td><?php echo e($confirm->bookingId); ?></td>
                       <td><?php echo e($confirm->account_name); ?></td>
                       <td><?php echo e($confirm->bank_name); ?></td>
                       <td><?php echo e($confirm->amount_sent); ?></td>
                       <td><?php echo e($confirm->full_name); ?></td>
                       <td>
                           <?php if($confirm->verify_status == "accepted"): ?>
                           <span class="btn btn-success btn-sm">accepted</span>
                           <?php elseif($confirm->verify_status == "pending"): ?>
                           <span class="btn btn-warning btn-sm">Awaiting confirmation</span>
                           <?php else: ?>
                           <span class="btn btn-danger btn-sm">rejected</span>
                           <?php endif; ?>
                      
                       <td>
                        
                       <a href="<?php echo e(route('confirm.edit', $confirm->id)); ?>" ><i style="color:blue;" class="bi bi-pencil-square"></i></a>
                          <a href="#" data-toggle="modal" data-target="#confirm_<?php echo e($confirm->id); ?>" ><i style="color:red;" class="bi bi-trash"></i></a>
                      </td>
                      <?php echo $__env->make('backend.modals.deleteConfirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php else: ?>
                     <p class="text-center">No recent payment Confirmation</p>
                     <?php endif; ?>

                      
                    </tbody>
              </table>

            </div>

          </div>
        </div><!-- End Recent Sales -->

    

      </div>
    </div><!-- End Left side columns -->

  

  </div>
</section>

</main><!-- End #main -->

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/all_confirms.blade.php ENDPATH**/ ?>