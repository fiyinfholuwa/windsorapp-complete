


 <?php $__env->startSection('content'); ?>
 
 <main id="main" class="main">



<section class="section dashboard">
  <div class="row">

        <!-- Recent Sales -->
        <div class="col-12">
          <div class="card recent-sales overflow-auto">

           

            <div class="card-body">
              <h5 class="card-title">All Applied Jobs <span></span></h5>

              <table class="table table-borderless datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Full Name</th>
                    <th scope="col">Phone Number</th>
                    <th scope="col">Email</th>
                    <th scope="col">Resume</th>
                    <th scope="col">Job Title</th>
                    <th scope="col">Cover Letter</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody>
                 
                 
                <?php if(count($jobs_applied) > 0): ?>
                <?php $num = 1; ?>
              <?php $__currentLoopData = $jobs_applied; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                  <td><?php echo e($num++); ?></td>
                  <td><?php echo e($job->fullname); ?></td>
                  <td><?php echo e($job->phoneNumber); ?></td>
                  <td><?php echo e($job->email); ?></td>
                  <td><a href="<?php echo e(asset($job->resume)); ?>" target="_blank" class="btn btn-primary btn-sm" style="font-size: 8px;">Open Resume</a></td>
                  <td><?php echo e($job->jobTitle); ?></td>
                  <td><?php if($job->cover_letter ==NULL): ?>
                  <span  class="btn btn-danger btn-sm" style="font-size: 8px;">No letter</span>
                  <?php else: ?>
                  <a href="#" data-toggle="modal" data-target="#readLetter_<?php echo e($job->id); ?>"class="btn btn-success btn-sm"style="font-size: 8px;" >read letter</a>
                  <?php endif; ?>
                  </td>
                  
                  <td><a href="#" data-toggle="modal" data-target="#jobApply_<?php echo e($job->id); ?>" ><i style="color:red;" class="bi bi-trash"></i></a>
                
                </td>
                  <?php echo $__env->make('backend.modals.deleteJobApply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <?php echo $__env->make('backend.modals.readLetter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>
              <tr>
                <td colspan="5" class="text-center">No Data Found</td>
              </tr>
            <?php endif; ?>
                </tbody>
              </table>

            </div>

          </div>
        </div><!-- End Recent Sales -->

    

      </div>
    </div><!-- End Left side columns -->

  

  </div>
</section>

</main><!-- End #main -->

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\windsorApp\resources\views/backend/jobs-apply-all.blade.php ENDPATH**/ ?>